package com.personal.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    // Table and column names for Users table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Table and column names for Inventory table
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COLUMN_ITEM_ID = "item_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_ITEM_QUANTITY = "item_quantity";

    // SQL statement to create Users table
    private static final String TABLE_CREATE_USERS =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT UNIQUE, " +
                    COLUMN_PASSWORD + " TEXT);";

    // SQL statement to create Inventory table
    private static final String TABLE_CREATE_INVENTORY =
            "CREATE TABLE " + TABLE_INVENTORY + " (" +
                    COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_ITEM_NAME + " TEXT, " +
                    COLUMN_ITEM_QUANTITY + " INTEGER);";

    // SQL statements to create indexes for performance improvement
    private static final String INDEX_CREATE_USERNAME =
            "CREATE INDEX idx_username ON " + TABLE_USERS + " (" + COLUMN_USERNAME + ");";

    private static final String INDEX_CREATE_ITEM_NAME =
            "CREATE INDEX idx_item_name ON " + TABLE_INVENTORY + " (" + COLUMN_ITEM_NAME + ");";

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            // Execute SQL statements to create tables and indexes
            db.execSQL(TABLE_CREATE_USERS);
            db.execSQL(TABLE_CREATE_INVENTORY);
            db.execSQL(INDEX_CREATE_USERNAME);
            db.execSQL(INDEX_CREATE_ITEM_NAME);
        } catch (SQLException e) {
            Log.e("DatabaseHelper", "Error creating database", e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrade if needed (e.g., adding new columns or tables)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // Helper method to add a new user
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Helper method to check if a user already exists
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { COLUMN_USER_ID };
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = { username };

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Helper method to add a new item to the inventory
    public boolean addItem(String itemName, int itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_ITEM_QUANTITY, itemQuantity);

        long result = db.insert(TABLE_INVENTORY, null, values);
        return result != -1;
    }

    // Helper method to update an existing item in the inventory
    public boolean updateItem(String itemName, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_QUANTITY, newQuantity);

        String selection = COLUMN_ITEM_NAME + " = ?";
        String[] selectionArgs = { itemName };

        int count = db.update(TABLE_INVENTORY, values, selection, selectionArgs);
        return count > 0;
    }

    // Helper method to delete an item from the inventory
    public boolean deleteItem(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = COLUMN_ITEM_NAME + " = ?";
        String[] selectionArgs = { itemName };

        int deletedRows = db.delete(TABLE_INVENTORY, selection, selectionArgs);
        return deletedRows > 0;
    }

    // Helper method to fetch all items from the inventory
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_INVENTORY, null, null, null, null, null, null);
    }
}

