package com.personal.myapplication;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class InventoryDisplayActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private Button addButton, removeButton, updateButton, smsPermissionButton, backButton;
    private EditText itemNameEditText, itemQuantityEditText;
    private DatabaseHelper dbHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_display);

        // Initialize UI components
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        itemNameEditText = findViewById(R.id.item_name);
        itemQuantityEditText = findViewById(R.id.item_quantity);
        addButton = findViewById(R.id.add_button);
        removeButton = findViewById(R.id.remove_button);
        updateButton = findViewById(R.id.update_button);
        smsPermissionButton = findViewById(R.id.sms_permission_button);
        backButton = findViewById(R.id.back_button_inventory);

        dbHelper = new DatabaseHelper(this);

        loadInventoryData();

        // Set up click listeners for each button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleAddItem();
            }
        });

        removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleRemoveItem();
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleUpdateItem();
            }
        });

        smsPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToSmsPermissionScreen();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the LoginActivity and finish the current activity
                Intent intent = new Intent(InventoryDisplayActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void loadInventoryData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                DatabaseHelper.COLUMN_ITEM_NAME,
                DatabaseHelper.COLUMN_ITEM_QUANTITY
        };

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_INVENTORY,   // The table to query
                projection,                       // The columns to return
                null,                             // The columns for the WHERE clause
                null,                             // The values for the WHERE clause
                null,                             // Don't group the rows
                null,                             // Don't filter by row groups
                null                              // The sort order
        );

        List<InventoryItem> inventoryItems = new ArrayList<>();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int itemQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_QUANTITY));
                inventoryItems.add(new InventoryItem(itemName, itemQuantity));
            }
            cursor.close();
        }

        adapter = new InventoryAdapter(this, inventoryItems);
        recyclerView.setAdapter(adapter);
    }

    private void handleAddItem() {
        try {
            String itemName = itemNameEditText.getText().toString();
            String itemQuantity = itemQuantityEditText.getText().toString();

            if (itemName.isEmpty() || itemQuantity.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_ITEM_NAME, itemName);
            values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, Integer.parseInt(itemQuantity));

            long newRowId = db.insert(DatabaseHelper.TABLE_INVENTORY, null, values);
            if (newRowId != -1) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                loadInventoryData();
            } else {
                Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void handleRemoveItem() {
        try {
            String itemName = itemNameEditText.getText().toString();

            if (itemName.isEmpty()) {
                Toast.makeText(this, "Please enter the item name to remove", Toast.LENGTH_SHORT).show();
                return;
            }

            SQLiteDatabase db = dbHelper.getWritableDatabase();
            String selection = DatabaseHelper.COLUMN_ITEM_NAME + " = ?";
            String[] selectionArgs = { itemName };

            int deletedRows = db.delete(DatabaseHelper.TABLE_INVENTORY, selection, selectionArgs);
            if (deletedRows > 0) {
                Toast.makeText(this, "Item removed", Toast.LENGTH_SHORT).show();
                loadInventoryData();
            } else {
                Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void handleUpdateItem() {
        try {
            String itemName = itemNameEditText.getText().toString();
            String itemQuantity = itemQuantityEditText.getText().toString();

            if (itemName.isEmpty() || itemQuantity.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, Integer.parseInt(itemQuantity));

            String selection = DatabaseHelper.COLUMN_ITEM_NAME + " = ?";
            String[] selectionArgs = { itemName };

            int count = db.update(DatabaseHelper.TABLE_INVENTORY, values, selection, selectionArgs);
            if (count > 0) {
                Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
                loadInventoryData();
            } else {
                Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void navigateToSmsPermissionScreen() {
        Intent intent = new Intent(InventoryDisplayActivity.this, NotificationSystemActivity.class);
        startActivity(intent);
    }
}
