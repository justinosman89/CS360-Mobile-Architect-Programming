package com.personal.myapplication;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ItemManagementActivity extends AppCompatActivity {

    private EditText itemNameEditText;
    private EditText itemQuantityEditText;
    private Button addButton;
    private Button removeButton;
    private Button updateButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_management);

        dbHelper = new DatabaseHelper(this);

        itemNameEditText = findViewById(R.id.item_name);
        itemQuantityEditText = findViewById(R.id.item_quantity);
        addButton = findViewById(R.id.add_button);
        removeButton = findViewById(R.id.remove_button);
        updateButton = findViewById(R.id.update_button);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addItem();
            }
        });

        removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeItem();
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateItem();
            }
        });
    }

    private void addItem() {
        String itemName = itemNameEditText.getText().toString();
        String itemQuantity = itemQuantityEditText.getText().toString();

        if (TextUtils.isEmpty(itemName) || TextUtils.isEmpty(itemQuantity)) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, itemName);
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, Integer.parseInt(itemQuantity));

        long newRowId = db.insert(DatabaseHelper.TABLE_INVENTORY, null, values);
        if (newRowId != -1) {
            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
        }
    }

    private void removeItem() {
        String itemName = itemNameEditText.getText().toString();

        if (TextUtils.isEmpty(itemName)) {
            Toast.makeText(this, "Please fill out the item name", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String selection = DatabaseHelper.COLUMN_ITEM_NAME + " LIKE ?";
        String[] selectionArgs = { itemName };

        int deletedRows = db.delete(DatabaseHelper.TABLE_INVENTORY, selection, selectionArgs);
        if (deletedRows > 0) {
            Toast.makeText(this, "Item removed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateItem() {
        String itemName = itemNameEditText.getText().toString();
        String itemQuantity = itemQuantityEditText.getText().toString();

        if (TextUtils.isEmpty(itemName) || TextUtils.isEmpty(itemQuantity)) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, Integer.parseInt(itemQuantity));

        String selection = DatabaseHelper.COLUMN_ITEM_NAME + " LIKE ?";
        String[] selectionArgs = { itemName };

        int count = db.update(
                DatabaseHelper.TABLE_INVENTORY,
                values,
                selection,
                selectionArgs);

        if (count > 0) {
            Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
        }
    }
}


